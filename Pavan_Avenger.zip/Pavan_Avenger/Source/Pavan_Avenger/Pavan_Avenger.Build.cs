// Copyright [Your Name]

using UnrealBuildTool;
using System.IO;

public class Pavan_Avenger : ModuleRules
{
    public Pavan_Avenger(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicIncludePaths.AddRange(
            new string[] {
                Path.Combine(ModuleDirectory, "Public")
            }
        );

        PrivateIncludePaths.AddRange(
            new string[] {
                Path.Combine(ModuleDirectory, "Private")
            }
        );

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "AndroidPermission",   // Required for Android file permissions
                "ApplicationCore",     // Required for accessing external storage paths
                "Engine"
            }
        );

        PrivateDependencyModuleNames.AddRange(
            new string[]
            {
                "CoreUObject",
                "Slate",
                "SlateCore"
            }
        );

        DynamicallyLoadedModuleNames.AddRange(new string[] { });

        if (Target.Platform == UnrealTargetPlatform.Android)
        {
            PrivateDependencyModuleNames.Add("Launch");

            // Ensure Android UPL file is included
            AdditionalPropertiesForReceipt.Add("AndroidPlugin",
                Path.Combine(ModuleDirectory, "Pavan_Avenger_Android_UPL.xml"));
        }
    }
}