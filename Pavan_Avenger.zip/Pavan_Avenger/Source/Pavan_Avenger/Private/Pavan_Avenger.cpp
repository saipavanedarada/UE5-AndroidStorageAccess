// Copyright Epic Games, Inc. All Rights Reserved.

#include "Pavan_Avenger.h"

#define LOCTEXT_NAMESPACE "FPavan_AvengerModule"

void FPavan_AvengerModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
}

void FPavan_AvengerModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FPavan_AvengerModule, Pavan_Avenger)