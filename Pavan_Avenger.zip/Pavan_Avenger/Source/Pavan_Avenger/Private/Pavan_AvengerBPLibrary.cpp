// Copyright [Your Name]

#include "Pavan_AvengerBPLibrary.h"
#include "Pavan_Avenger.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFilemanager.h"
#include "GenericPlatform/GenericPlatformFile.h"

#if PLATFORM_ANDROID
#include "AndroidPermissionFunctionLibrary.h"
#include "Android/AndroidJNI.h"
#include "Android/AndroidApplication.h"
#endif

FString UPavan_AvengerBPLibrary::CustomDirectoryPath = TEXT("");

UPavan_AvengerBPLibrary::UPavan_AvengerBPLibrary(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
}

float UPavan_AvengerBPLibrary::Pavan_AvengerSampleFunction(float Param)
{
    return -1;
}

void UPavan_AvengerBPLibrary::SetCustomDirectory(const FString& DirectoryPath)
{
    CustomDirectoryPath = DirectoryPath;
}

FString UPavan_AvengerBPLibrary::GetFilePath(const FString& FileName)
{
    if (CustomDirectoryPath.IsEmpty())
    {
        return TEXT(""); // No directory set
    }
    return CustomDirectoryPath / FileName;
}

bool UPavan_AvengerBPLibrary::CreateCustomFolder()
{
    if (CustomDirectoryPath.IsEmpty())
    {
        return false; // No directory set
    }

    IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

    if (!PlatformFile.DirectoryExists(*CustomDirectoryPath))
    {
        return PlatformFile.CreateDirectoryTree(*CustomDirectoryPath);
    }

    return true;
}

bool UPavan_AvengerBPLibrary::WriteToFile(const FString& FileName, const FString& Text)
{
    FString FilePath = GetFilePath(FileName);
    if (FilePath.IsEmpty()) return false;
    CreateCustomFolder();
    return FFileHelper::SaveStringToFile(Text, *FilePath);
}

bool UPavan_AvengerBPLibrary::ReadFromFile(const FString& FileName, FString& OutText)
{
    FString FilePath = GetFilePath(FileName);
    if (FilePath.IsEmpty()) return false;
    return FFileHelper::LoadFileToString(OutText, *FilePath);
}

bool UPavan_AvengerBPLibrary::DeleteFile(const FString& FileName)
{
    FString FilePath = GetFilePath(FileName);
    if (FilePath.IsEmpty()) return false;
    return IFileManager::Get().Delete(*FilePath);
}

void UPavan_AvengerBPLibrary::RequestStoragePermission()
{
#if PLATFORM_ANDROID
    TArray<FString> Permissions;
    Permissions.Add(TEXT("android.permission.READ_EXTERNAL_STORAGE"));
    Permissions.Add(TEXT("android.permission.WRITE_EXTERNAL_STORAGE"));
    Permissions.Add(TEXT("android.permission.MANAGE_EXTERNAL_STORAGE"));

    UAndroidPermissionFunctionLibrary::AcquirePermissions(Permissions);
#endif
}