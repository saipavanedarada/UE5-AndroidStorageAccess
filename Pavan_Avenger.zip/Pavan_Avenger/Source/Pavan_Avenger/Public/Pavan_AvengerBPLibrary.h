// Copyright [Your Name]

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Pavan_AvengerBPLibrary.generated.h"

UCLASS()
class PAVAN_AVENGER_API UPavan_AvengerBPLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UPavan_AvengerBPLibrary(const FObjectInitializer& ObjectInitializer);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static float Pavan_AvengerSampleFunction(float Param);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static void SetCustomDirectory(const FString& DirectoryPath);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static FString GetFilePath(const FString& FileName);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static bool CreateCustomFolder();

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static bool WriteToFile(const FString& FileName, const FString& Text);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static bool ReadFromFile(const FString& FileName, FString& OutText);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger")
    static bool DeleteFile(const FString& FileName);

    UFUNCTION(BlueprintCallable, Category = "Pavan_Avenger|Android", meta = (Keywords = "Android Permission"))
    static void RequestStoragePermission();

private:
    static FString CustomDirectoryPath;
};